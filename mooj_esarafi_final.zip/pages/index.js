export default function Home() {
  return (
    <div style={{
      background: 'linear-gradient(#0099ff, #003366)',
      minHeight: '100vh',
      color: 'white',
      padding: '30px'
    }}>
      <h1>MOOJ E-SARAFI</h1>
      <p>Buy & Sell USDT (AFN / USD)</p>
    </div>
  );
}